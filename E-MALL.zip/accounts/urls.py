# urls.py
from django.urls import path
from .views import add_details, details_list

urlpatterns = [
    path('add/', add_details, name='add_details'),
    path('details/', details_list, name='details_list'),
]
