
from django.shortcuts import render, redirect , HttpResponse
from accounts.forms import UserForm
# Create your views here.
# views.py
from accounts.models import User

# views.py
def details_list(request):
    users = User.objects.all()
    return render(request, 'details_list.html', {'users': users})


def add_details(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/net/')
    else:
        form = UserForm()
    return render(request, 'add_details.html', {'form': form})
