from django.urls import path
from . import views

urlpatterns = [
    path('net/contact/', views.contact_form_view, name='contact_form'),
    path('msgs', views.contact_success_view, name='contact_success'),
]
