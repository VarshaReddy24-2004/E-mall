
from django.http import HttpResponse

from django.template import loader

from django.shortcuts import render
from .models import User


from django.shortcuts import render, redirect , HttpResponse
from accounts.forms import UserForm
# Create your views here.
# views.py
from accounts.models import User
from django.shortcuts import render, redirect
from emallapp.models import User

def net(request):
    template=loader.get_template('index.html')
    return HttpResponse(template.render())
def login(request):
    template=loader.get_template('login.html')
    return HttpResponse(template.render())
def stationary(request):
    template=loader.get_template('stationary.html')
    return HttpResponse(template.render())
def grocery(request):
    template=loader.get_template('grocery.html')
    return HttpResponse(template.render())
def electronics(request):
    template=loader.get_template('electronics.html')
    return HttpResponse(template.render())
def footwear(request):
    template=loader.get_template('footwear.html')
    return HttpResponse(template.render())
def beauty(request):
    template=loader.get_template('beauty.html')
    return HttpResponse(template.render())
def homeproduct(request):
    template=loader.get_template('homeproducts.html')
    return HttpResponse(template.render())
def decorations(request):
    template=loader.get_template('decorations.html')
    return HttpResponse(template.render())
def clothing(request):
    template=loader.get_template('clothing.html')
    return HttpResponse(template.render())

def medical(request):
    template=loader.get_template('medicals.html')
    return HttpResponse(template.render())
def payment(request):
    template=loader.get_template('payment.html')
    return HttpResponse(template.render())
# In views.py



# views.py
def details_list(request):
    users = User.objects.all()
    return render(request, 'details_list.html', {'users': users})


def add_details(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('details_list')
    else:
        form = UserForm()
    return render(request, 'add_details.html', {'form': form})
