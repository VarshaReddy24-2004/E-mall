from django import forms
from emallapp.models import User
class LoginForm(forms.ModelForm):
    class Meta:
        model=User
        fields='__all__'
        #exclude=['Sno'] use this if you dont need that field

    
