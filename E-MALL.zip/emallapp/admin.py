from django.contrib import admin
#from crudApp.models import Student
from emallapp.models import User

class UserAdmin(admin.ModelAdmin):
    userInfo=['username','password']
admin.site.register(User,UserAdmin)