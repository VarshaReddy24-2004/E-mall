
from django.urls import path
from emallapp import views

from accounts.views import add_details, details_list



urlpatterns=[
    path('net/',views.net),
    path('net/stationary/',views.stationary),
    path('net/grocery/',views.grocery),
    path('net/electronics/',views.electronics),
    path('net/footwear/',views.footwear),
    path('net/beauty/',views.beauty),
    path('net/homeproducts/',views.homeproduct),
    path('net/decorations/',views.decorations),
    path('net/clothing/',views.clothing),
    path('net/medical/',views.medical),

    path('net/stationary/payment/',views.payment),
    path('net/grocery/payment/',views.payment),
    path('net/electronics/payment/',views.payment),
    path('net/footwear/payment/',views.payment),
    path('net/beauty/payment/',views.payment),
    path('net/homeproducts/payment/',views.payment),
    path('net/decorations/payment/',views.payment),
    path('net/clothing/payment/',views.payment),

    
    path('net/add/', add_details, name='add_details'),
    
    

    # In urls.py


    
    


]